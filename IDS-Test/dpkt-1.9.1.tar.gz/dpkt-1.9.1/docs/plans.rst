*****************
Development plans
*****************

Current plans
=============

- Be Awesome

Future plans
============

- Maintain the Awesome
